package stepDefs;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import utils.SeleniumSupport;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ImanageLoginStepDefination {

	@Given("^I want to login into imanage with \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_want_to_login_into_imanage_with(final String companyId, final String employeeId, final String password)
			throws Throwable {
		// IMPLICIT WAIT
		SeleniumSupport.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		SeleniumSupport.driver.findElement(By.xpath("//input[@name='COMPANY']")).sendKeys(companyId);
		SeleniumSupport.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		SeleniumSupport.driver.findElement(By.xpath("//input[@name='USERID']")).clear();
		SeleniumSupport.driver.findElement(By.xpath("//input[@name='USERID']")).sendKeys(employeeId);
		SeleniumSupport.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		SeleniumSupport.driver.findElement(By.xpath("//input[@name='PASSWORD']")).clear();
		SeleniumSupport.driver.findElement(By.xpath("//input[@name='PASSWORD']")).sendKeys(password);
	}

	@When("^click on the submit button$")
	public void click_on_the_submit_button() throws Throwable {
		SeleniumSupport.driver.findElement(By.xpath("//input[@name='BTNSUBMIT']")).click();
		Thread.sleep(4);
		int size = SeleniumSupport.driver.findElements(By.tagName("frame")).size();
		System.out.println("frames" + size);
		SeleniumSupport.driver.switchTo().frame("Fra_Menu");

		WebElement PromotionsSection = SeleniumSupport.driver.findElement(By.xpath("//*[@id=\"s6\"]/div/table/tbody/tr/td[1]"));
		PromotionsSection.click();
		SeleniumSupport.driver.findElement(By.xpath("//*[@id=\"H_153\"]/table/tbody/tr[1]/td[2]/a")).click();

		SeleniumSupport.driver.switchTo().defaultContent();
		SeleniumSupport.driver.switchTo().frame("Fra_Detail");
		
		SeleniumSupport.driver.findElement(By.xpath("html/body/form/table[4]/tbody/tr[2]/td/table/tbody/tr[5]/td[7]/textarea")).sendKeys("Siddharth");
		
	}

	@Then("^I will validate the succesful login$")
	public void i_will_validate_the_succesful_login() throws Throwable {
		System.out.println("Inside vaidate condition");
	}

	@Then("^check more outcomes$")
	public void check_more_outcomes() throws Throwable {
		System.out.println("Inside and condition");
	}
	
	@Then("^I logout$")
	public void i_logout() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}
}
