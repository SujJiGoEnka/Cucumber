package stepDefs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.google.common.collect.Lists;

public class LamdaDemo {

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(1, 23, 4, 5, 6, 7);
		List<String> al = Lists.newArrayList();
		al.add("sidd");
		al.add("ashutosh");
		al.add("patil");
		al.add("sangli");
		System.out.println(al);
		/*		list.forEach(number -> System.out.println(number));
		
		String s1 = new String("test");
		String s2 = new String("test");
		if(s1==s2)
			System.out.println(true);
		else
			System.out.println(false);
	*/}
}
